#!/usr/bin/env python3
import sys
#Word Count Example
# input comes from standard input STDIN
for line in sys.stdin:
    line = line.strip() #remove leading and trailing whitespaces
    words = line.split(" ") #split the line into words and returns as a list
    for word1 in words:
        for word2 in words:
            if word1 == word2:
                continue
            print('%s\t%s\t%s' % (word1,"*","1")) #Emit the word   
            print('%s\t%s\t%s' % (word1,word2,"1")) #Emit the word 
 