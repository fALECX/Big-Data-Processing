#!/bin/bash    

# Remove the HDFS output directory forcefully and recursively.
hadoop fs -rm -r -f /output

#-D stream.map.output.field.separator="\t" note if seperator is \t, do not specify this line !!
#-D map.output.key.field.separator="\t"   note if seperator is \t, do not specify this line !!
hadoop jar /usr/lib/hadoop/hadoop-streaming.jar \
-D stream.num.map.output.key.fields=2 \
-D mapred.text.key.partitioner.options=-k1,1 \
-D mapreduce.job.reduces=3 \
-files ./mapper.py,./reducer.py \
-mapper ./mapper.py \
-reducer ./reducer.py \
-input /trip.txt \
-output /output \
-partitioner org.apache.hadoop.mapred.lib.KeyFieldBasedPartitioner 





