#!/bin/bash

# Remove the HDFS output directory forcefully and recursively.
hadoop fs -rm -r -f /output20

hadoop jar /usr/lib/hadoop/hadoop-streaming.jar \
-D mapreduce.job.reduces=2 \
-files ./mapper.py,./reducer.py \
-mapper ./mapper.py \
-reducer ./reducer.py \
-input /trip.txt \
-output /output20





