#!/usr/bin/env python3
import sys
#from operator import itemgetter
# using a dictionary to map words to their counts
#current_word = None
#current_count = 0
#times = 0
#word = None
# input comes from STDIN

word1 = None
word2 = None
current_word1 = None
current_word2 = None
current_count = 0
for line in sys.stdin:
    line = line.strip()
    word1,word2,count = line.split('\t')
    try:
        count = int(count)
    except ValueError:
        continue
    if current_word1 == word1 and current_word2 == word2:
        current_count += count
    else:
        if current_word1:
            print('%s\t%s\t%s' % (current_word1, current_word2, current_count))
        current_count = count
        current_word1 = word1
        current_word2 = word2
if current_word1 == word1 and current_word2 == word2:
    print('%s\t%s\t%s' % (current_word1, current_word2, current_count))



#!/usr/bin/env python3
# import sys
# from operator import itemgetter
# # using a dictionary to map words to their counts
# current_word = None
# current_count = 0
# word = None
# # input comes from STDIN
# for line in sys.stdin:
    # line = line.strip()
    # word,count = line.split('\t',1)
    # try:
        # count = int(count)
    # except ValueError:
        # continue
    # if current_word == word:
        # current_count += count
    # else:
        # if current_word:
               # print('%s\t%s' % (current_word, current_count))
        # current_count = count
        # current_word = word
# if current_word == word:
    # print('%s\t%s' % (current_word,current_count))