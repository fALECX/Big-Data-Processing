#!/bin/bash    

# Remove the HDFS output directory forcefully and recursively.
hadoop fs -rm -r -f /output

hadoop jar /usr/lib/hadoop/hadoop-streaming.jar \
-D stream.map.output.field.separator="\t" \
-D stream.num.map.output.key.fields=2 \
-D mapreduce.job.reduces=3 \
-files ./mapper.py,./reducer.py \
-mapper ./mapper.py \
-reducer ./reducer.py \
-input /trip.txt \
-output /output

