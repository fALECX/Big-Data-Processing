#!/usr/bin/env python3
import sys
#from operator import itemgetter
# using a dictionary to map words to their counts
#current_word = None
#current_count = 0
#times = 0
#word = None
# input comes from STDIN

#word1 = None
#word2 = None
current_word = None
#current_word2 = None
#current_count = 0
mylist = []
first1ine = 1
firstword = 1
for line in sys.stdin:
    line = line.strip()
    word1,words = line.split(';',1)
    if current_word == word1 or first1ine == 1:
        first1ine = 0
        wordlist = words.split(";")
        wordlist = wordlist[0:len(wordlist)-1]
        
        #print(wordlist)
        #print(len(wordlist))
        for w in wordlist:
            #print("=====%s\t%s======"%(word1,w))
            ww,count = w.split(",")
            listpos = 0
            flag = 1
            for ew in mylist:
                eww,ewcount = ew.split(",")
                if eww == ww:
                    ewcount = str(int(ewcount) + int(count))                
                    flag = 0
                mylist[listpos] = eww + "," + ewcount
                listpos = listpos + 1
            if flag == 1:
                mylist.append(w)
                #print("-----%s--------"% w)
    else:
        #print("44444444====%s===444444" % current_word)
        if current_word:
            print('%s;' % (current_word), end = "")
            num = len(mylist)
            i = 0
            for ew in mylist:
                eww,ewcount = ew.split(",")
                if i < num - 1:
                    print('%s,%s;' % (eww, ewcount), end = "")
                if i == num - 1:
                    print('%s,%s' % (eww, ewcount), end = "")
                i = i + 1        
            print("")
                
        if firstword != 1:        
            mylist = []
        firstword = 0    
        current_word = word1
        wordlist = words.split(";")
        wordlist = wordlist[0:len(wordlist)-1]
        for w in wordlist:
            ww,count = w.split(",")
            listpos = 0
            flag = 1
            for ew in mylist:
                eww,ewcount = ew.split(",")
                if eww == ww:
                    ewcount = str(int(ewcount) + int(count))
                    flag = 0                    
                mylist[listpos] = eww + "," + ewcount
                listpos = listpos + 1
            if flag == 1:
                mylist.append(w)

if current_word:
    print('%s;' % (current_word), end = "")
    num = len(mylist)
    i = 0
    for ew in mylist:
        eww,ewcount = ew.split(",")
        if i < num - 1:
            print('%s,%s;' % (eww, ewcount), end = "")
        if i == num - 1:
            print('%s,%s' % (eww, ewcount), end = "")
        i = i + 1        
    print("")


