#!/usr/bin/env python3
import sys
#Word Count Example
# input comes from standard input STDIN
#dict = {}
for line in sys.stdin:
    line = line.strip() #remove leading and trailing whitespaces
    words = line.split(" ") #split the line into words and returns as a list
    for word1 in words:
        #list = []
        print('%s' % word1, end=";")
        for word2 in words:
            if word1 == word2:
                continue
        #    list.append(word2+","+"1")
        #dict[word1]=list
        
            print('%s,%s' % (word2,"1"), end=";") #Emit the word 
        print("")