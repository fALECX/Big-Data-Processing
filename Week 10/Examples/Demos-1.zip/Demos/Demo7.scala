import scala.io.Source 

object Demo7 { 
      def main(args: Array[String]) { 
	    print("Please enter your input : \n" ) 
            val line = scala.io.StdIn.readLine() 

             println("Following is the content read:\n" ) 
             Source.fromFile(line ).foreach { 
                   print 
             } 
       } 
} 
