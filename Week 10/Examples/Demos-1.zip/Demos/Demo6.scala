import java.io._ 

object Demo6 { 
        def main(args: Array[String]) { 
               print("Please enter your input : " ) 
               val line = scala.io.StdIn.readLine() 
               println("Thanks, you just typed: " + line) 
        } 
} 

