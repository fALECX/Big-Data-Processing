import java.io._ 

object Demo3 { 
    def main(args: Array[String]) { 
          val writer = new PrintWriter(new File("test.txt" )) 
          writer.write("Hello Scala") 
          writer.close() 
    } 
} 

