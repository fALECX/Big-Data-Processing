#!/bin/bash

# Remove the HDFS output directory forcefully and recursively.
hadoop fs -rm -r -f /mapreduce-output*

i=1
while :
do
	hadoop jar /usr/lib/hadoop/hadoop-streaming.jar \
    -D mapreduce.job.reduces=3 \
    -D mapred.text.key.partitioner.options=-k1 \
    -files ./centroids.txt,./reducer.py,./mapper.py \
    -mapper ./mapper.py \
    -reducer ./reducer.py \
    -input /dataset.txt \
    -output /mapreduce-output$i \
    -partitioner org.apache.hadoop.mapred.lib.KeyFieldBasedPartitioner
        
    rm -f centroids1.txt
    hadoop fs -getmerge /mapreduce-output$i/part* centroids1.txt
	
    seeiftrue=`python reader.py` 
	
	if [ $seeiftrue = 1 ]
	then
		rm centroids.txt
		hadoop fs -getmerge /mapreduce-output$i/part* centroids.txt
		break
	else
		rm centroids.txt
		hadoop fs -getmerge /mapreduce-output$i/part* centroids.txt
	fi
	i=$((i+1))
done

